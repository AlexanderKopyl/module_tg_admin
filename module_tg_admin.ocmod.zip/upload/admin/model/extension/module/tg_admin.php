<?php
class ModelExtensionModuleTgAdmin extends Model {

}